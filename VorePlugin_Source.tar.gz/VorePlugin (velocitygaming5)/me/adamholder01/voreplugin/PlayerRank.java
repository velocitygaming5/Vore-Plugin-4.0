package VorePlugin (velocitygaming5).me.adamholder01.voreplugin;







public enum PlayerRank
{
 PREDATOR,
 SWITCH,
 PREY;
}
