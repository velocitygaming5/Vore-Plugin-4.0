package VorePlugin (velocitygaming5).me.adamholder01.voreplugin;

import me.adamholder01.voreplugin.PlayerRank;
import me.adamholder01.voreplugin.VorePlugin;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

class PlaceholderHook
  extends PlaceholderExpansion {
  public PlaceholderHook(VorePlugin plugin) {
    this.plugin = plugin;
  }
  private final VorePlugin plugin;

  public boolean persist() {
    return true;
  }


  public boolean canRegister() {
    return true;
  }


  public String getIdentifier() {
    return "VorePlugin";
  }


  public String getAuthor() {
    return this.plugin.getDescription().getAuthors().toString();
  }


  public String getVersion() {
    return this.plugin.getDescription().getVersion();
  }


  public String onPlaceholderRequest(Player player, String identifier) {
    if (player == null) {
      return "";
    }


    if (identifier.equals("rank")) {
      PlayerRank rank = VorePlugin.getPlayerRank(player);
      return rank.name().toLowerCase();
    }
    return null;
  }
}
