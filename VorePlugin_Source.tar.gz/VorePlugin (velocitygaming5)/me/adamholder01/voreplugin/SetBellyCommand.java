package VorePlugin (velocitygaming5).me.adamholder01.voreplugin;

import me.adamholder01.voreplugin.HitListener;
import me.adamholder01.voreplugin.PlayerRank;
import me.adamholder01.voreplugin.VorePlugin;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;




class SetBellyCommand
  implements CommandExecutor

  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
    if (!(sender instanceof Player)) {
      sender.sendMessage("§8[§b§lVorePlugin§8] §cYou cannot run that command from the console.");
      return true;
    } 
    
    if (args.length != 1) return false;
    
    String name = args[0];
    Player p = (Player)sender;
    Location loc = p.getLocation();
    World world = p.getWorld();
    
    if (VorePlugin.getPlayerRank(p) == PlayerRank.PREY) { sender.sendMessage("§8[§b§lVorePlugin§8] §cThe prey rank cannot set a belly."); return true; }
    
    FileConfiguration playerFile = VorePlugin.getPlayerFile(p);
    ConfigurationSection playerLocations = playerFile.getConfigurationSection("locations");
    
    int bellies = 0;
    try {
      bellies = (new HitListener()).getLocations(p).size();
    } catch (NullPointerException nullPointerException) {}


    
    if (bellies >= 4) {
      sender.sendMessage("§8[§b§lVorePlugin§8] §cYou can only have 4 bellies set at once.");
      return true;
    } 
    
    assert playerLocations != null;
    
    playerLocations.set(name + ".world", world.getUID().toString());
    
    playerLocations.set(name + ".x", Double.valueOf(loc.getX()));
    playerLocations.set(name + ".y", Double.valueOf(loc.getY()));
    playerLocations.set(name + ".z", Double.valueOf(loc.getZ()));
    
    playerLocations.set(name + ".yaw", Float.valueOf(loc.getYaw()));
    playerLocations.set(name + ".pitch", Float.valueOf(loc.getPitch()));
    
    VorePlugin.savePlayerFile(p, playerFile);
    
    sender.sendMessage("§8[§b§lVorePlugin§8] §aSuccessfully set the belly \"" + args[0] + "\" to your location.");
    return true;
  }
}
