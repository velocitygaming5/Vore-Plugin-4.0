package VorePlugin (velocitygaming5).me.adamholder01.voreplugin;

import me.adamholder01.voreplugin.PlayerRank;
import me.adamholder01.voreplugin.VorePlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;




public class ReleaseCommand
  implements CommandExecutor

  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
    if (!(sender instanceof Player)) {
      sender.sendMessage("§8[§b§lVorePlugin§8] §cYou cannot run that command from the console.");
      return true;
    }
    if (args.length != 1) {
      return false;
    }
    Player target = Bukkit.getPlayer(args[0]);
    Player p = (Player)sender;

    if (target == null) { p.sendMessage("§8[§b§lVorePlugin§8] §cThere is no player online called \"" + args[0] + "\"."); return true; }

    if (VorePlugin.getPlayerRank(target) == PlayerRank.PREDATOR) { p.sendMessage("§8[§b§lVorePlugin§8] §cYou cannot release predators."); return true; }

    if (!VorePlugin.releaseLocations.containsKey(target)) { p.sendMessage("§8[§b§lVorePlugin§8] §cThere is nowhere to release " + args[0] + " to."); return true; }

    Location release = (Location)VorePlugin.releaseLocations.get(target);
    target.teleport(release);
    VorePlugin.releaseLocations.remove(target);
    p.sendMessage("§8[§b§lVorePlugin§8] §aSuccessfully released " + args[0] + ".");
    return true;
  }
}
