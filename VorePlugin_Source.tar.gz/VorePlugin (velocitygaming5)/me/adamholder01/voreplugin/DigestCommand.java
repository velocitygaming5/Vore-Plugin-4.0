package VorePlugin (velocitygaming5).me.adamholder01.voreplugin;

import me.adamholder01.voreplugin.PlayerRank;
import me.adamholder01.voreplugin.VorePlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;





class DigestCommand
  implements CommandExecutor

  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
    if (!(sender instanceof Player)) {
      sender.sendMessage("§8[§b§lVorePlugin§8] §cYou cannot run that command from the console.");
      return true;
    }
    if (args.length != 1) {
      return false;
    }
    Player target = Bukkit.getPlayer(args[0]);
    Player p = (Player)sender;

    if (target == null) { p.sendMessage("§8[§b§lVorePlugin§8] §cThere is no player online called \"" + args[0] + "\"."); return true; }

    if (VorePlugin.getPlayerRank(target) == PlayerRank.PREDATOR) { p.sendMessage("§8[§b§lVorePlugin§8] §cYou cannot digest predators."); return true; }

    if (target.isInvulnerable()) { p.sendMessage("§8[§b§lVorePlugin§8] §c" + target.getName() + " is invulnerable. Are they in creative or god mode?"); return true; }

    PotionEffect wither = new PotionEffect(PotionEffectType.WITHER, 600, 2, false, false, false);

    target.addPotionEffect(wither);

    p.sendMessage("§8[§b§lVorePlugin§8] §aSuccessfully digesting " + target.getName() + ".");
    return true;
  }
}
