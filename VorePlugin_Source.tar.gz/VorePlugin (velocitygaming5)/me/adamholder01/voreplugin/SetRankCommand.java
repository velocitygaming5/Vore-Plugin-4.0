package VorePlugin (velocitygaming5).me.adamholder01.voreplugin;

import me.adamholder01.voreplugin.PlayerRank;
import me.adamholder01.voreplugin.VorePlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;




class SetRankCommand
  implements CommandExecutor

  public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
    PlayerRank rank;
    if (!(sender instanceof Player)) {
      sender.sendMessage("§8[§b§lVorePlugin§8] §cYou cannot run that command from the console.");
      return true;
    } 
    if (args.length != 1) {
      return false;
    }
    
    Player p = (Player)sender;
    
    try {
      rank = PlayerRank.valueOf(args[0].toUpperCase());
    } catch (Exception e) {
      sender.sendMessage("§8[§b§lVorePlugin§8] §c\"" + args[0] + "\" is not a rank. Please use predator, switch, or prey.");
      return true;
    } 
    FileConfiguration playerFile = VorePlugin.getPlayerFile(p);
    playerFile.set("rank", rank.name());
    VorePlugin.savePlayerFile(p, playerFile);
    
    sender.sendMessage("§8[§b§lVorePlugin§8] §aSuccessfully set your rank to " + rank.name() + ".");
    
    return true;
  }
}
