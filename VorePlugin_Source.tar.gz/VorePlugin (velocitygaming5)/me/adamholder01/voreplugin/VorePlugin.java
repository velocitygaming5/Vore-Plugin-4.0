package VorePlugin (velocitygaming5).me.adamholder01.voreplugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import me.adamholder01.voreplugin.DigestCommand;
import me.adamholder01.voreplugin.HitListener;
import me.adamholder01.voreplugin.PlaceholderHook;
import me.adamholder01.voreplugin.PlayerRank;
import me.adamholder01.voreplugin.ReleaseCommand;
import me.adamholder01.voreplugin.SetBellyCommand;
import me.adamholder01.voreplugin.SetRankCommand;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.CommandExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public class VorePlugin extends JavaPlugin implements Listener {
  static HashMap<Player, Location> releaseLocations = new HashMap<>();
  private static Plugin plugin;
  
  public void onEnable() {
    plugin = (Plugin)this;
    Bukkit.getLogger().info("VorePlugin was created for fiverr user \"velocitygaming5\" and is solely to be used by said user. With that being said, if any bugs are identified or any changes are required, DM adamholder01 on fiverr and they should be resolved in due time.");
    registerEvents(new Listener[] { (Listener)new HitListener(), this });
    getCommand("setbelly").setExecutor((CommandExecutor)new SetBellyCommand());
    getCommand("setrank").setExecutor((CommandExecutor)new SetRankCommand());
    getCommand("digest").setExecutor((CommandExecutor)new DigestCommand());
    getCommand("release").setExecutor((CommandExecutor)new ReleaseCommand());
    for (Player p : Bukkit.getOnlinePlayers()) {
      getPlayerFile(p);
    }
    
    if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
      (new PlaceholderHook(this)).register();
    }
  }

  
  public void onDisable() {
    plugin = null;
  }
  
  private static Plugin getPlugin() {
    return plugin;
  }
  
  private void registerEvents(Listener... listeners) {
    for (Listener l : listeners) {
      Bukkit.getPluginManager().registerEvents(l, getPlugin());
    }
  }
  
  static PlayerRank getPlayerRank(Player p) {
    String stringRank = getPlayerFile(p).getString("rank");
    PlayerRank rank = null;
    try {
      rank = PlayerRank.valueOf(stringRank);
    } catch (IllegalArgumentException e) {
      Bukkit.getLogger().warning("Could not retrieve " + p.getName() + "'s rank. Please check to see that the file " + getPlayerFile(p).toString() + " contains a path named rank.");
    } 
    return rank;
  }
  
  static FileConfiguration getPlayerFile(Player p) {
    File playerFile = new File(getPlugin().getDataFolder(), "/players/" + p.getUniqueId() + ".yml");
    if (!playerFile.exists()) {
      createPlayerFile(p);
    }
    return (FileConfiguration)YamlConfiguration.loadConfiguration(playerFile);
  }
  
  static void savePlayerFile(Player p, FileConfiguration playerCfg) {
    File playerFile = new File(getPlugin().getDataFolder(), "/players/" + p.getUniqueId() + ".yml");
    try {
      playerCfg.save(playerFile);
    } catch (IOException e) {
      e.printStackTrace();
    } 
  }
  
  @EventHandler
  public void onJoin(PlayerJoinEvent e) {
    getPlayerFile(e.getPlayer());
  }
  
  private static void createPlayerFile(Player p) {
    File dataFolder = getPlugin().getDataFolder();
    if (!dataFolder.exists()) {
      Bukkit.getLogger().info("Data folder not found, creating!");
      dataFolder.mkdir();
    } 
    
    File playersFolder = new File(dataFolder, "players");
    if (!playersFolder.exists()) {
      Bukkit.getLogger().info("Players folder not found, creating!");
      playersFolder.mkdir();
    } 
    
    File playerFile = new File(playersFolder, p.getUniqueId() + ".yml");
    if (!playerFile.exists())
      try {
        playerFile.createNewFile();
        
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration(playerFile);
        yamlConfiguration.set("rank", "SWITCH");
        yamlConfiguration.createSection("locations");
        yamlConfiguration.save(playerFile);
      }
      catch (IOException e) {
        e.printStackTrace();
      }  
  }
}
