package VorePlugin (velocitygaming5).me.adamholder01.voreplugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import me.adamholder01.voreplugin.PlayerRank;
import me.adamholder01.voreplugin.VorePlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

class HitListener implements Listener {
  @EventHandler
  public void onHit(EntityDamageByEntityEvent e) {
    Inventory selectGUI;
    if (!(e.getDamager() instanceof Player) || !(e.getEntity() instanceof Player))
      return;  Player damager = (Player)e.getDamager();
    Player target = (Player)e.getEntity();

    PlayerRank damagerRank = VorePlugin.getPlayerRank(damager);
    PlayerRank targetRank = VorePlugin.getPlayerRank(target);

    if (damagerRank == PlayerRank.PREY)
      return;  if (targetRank == PlayerRank.PREDATOR) {
      return;
    }

    try {
      selectGUI = createSelectGUI(damager, target);
    } catch (NullPointerException exception) {
      damager.sendMessage("§8[§b§lVorePlugin§8] §c" + exception.getMessage());

      return;
    }
    VorePlugin.releaseLocations.put(target, target.getLocation());

    damager.openInventory(selectGUI);
  }

  private Inventory createSelectGUI(Player p, Player target) throws NullPointerException {
    List<ItemStack> items = new ArrayList<>();
    HashMap<String, Location> locations = getLocations(p);
    for (Map.Entry<String, Location> entry : locations.entrySet()) {
      Location l = entry.getValue();
      ItemStack item = createGUIItem(entry.getKey(), l.getX(), l.getY(), l.getZ());
      items.add(item);
    }
    Inventory inv = Bukkit.createInventory((InventoryHolder)p, 9, "§bSelect a belly for " + target.getName() + ".");

    int count = 0;
    for (ItemStack item : items) {
      inv.addItem(new ItemStack[] { item });
      count++;
    }

    return inv;
  }

  HashMap<String, Location> getLocations(Player p) {
    FileConfiguration playerFile = VorePlugin.getPlayerFile(p);
    HashMap<String, Location> locations = new HashMap<>();
    ConfigurationSection section = playerFile.getConfigurationSection("locations");
    if (section == null) throw new NullPointerException("The locations section in " + p.getName() + "'s file is missing. Contact an admin for help.");

    Set<String> namesSet = section.getKeys(false);
    if (namesSet.isEmpty()) throw new NullPointerException("You have no locations set. Set one with /setbelly <name>.");

    for (String name : namesSet) {
      String path = "locations." + name;

      String worldString = playerFile.getString(path + ".world");
      if (worldString == null) throw new NullPointerException("The world from the location titled " + name + " in " + p.getUniqueId() + "'s file is missing.");

      World world = Bukkit.getWorld(UUID.fromString(worldString));

      double x = playerFile.getDouble(path + ".x");
      double y = playerFile.getDouble(path + ".y");
      double z = playerFile.getDouble(path + ".z");

      float yaw = playerFile.getInt(path + ".yaw");
      float pitch = playerFile.getInt(path + ".pitch");

      Location location = new Location(world, x, y, z, yaw, pitch);
      locations.put(name, location);
    }

    return locations;
  }

  private ItemStack createGUIItem(String name, double x, double y, double z) {
    ItemStack item = new ItemStack(Material.PAPER);
    ItemMeta meta = item.getItemMeta();

    assert meta != null;

    meta.setDisplayName("§b§l" + name);

    List<String> lore = new ArrayList<>();
    lore.add("§8X: " + (int)Math.rint(x));
    lore.add("§8Y: " + (int)Math.rint(y));
    lore.add("§8Z: " + (int)Math.rint(z));

    meta.setLore(lore);
    item.setItemMeta(meta);

    return item;
  }

  @EventHandler
  public void onInvClick(InventoryClickEvent e) {
    Inventory inv = e.getClickedInventory();
    String title = e.getView().getTitle();

    if (inv == null)
      return;
    if (title.startsWith("§bSelect a belly for ")) {
      e.setCancelled(true);
    }

    Player p = (Player)e.getWhoClicked();
    ItemStack item = e.getCurrentItem();

    if (item == null || item.getType() == Material.AIR)
      return;
    ItemMeta meta = item.getItemMeta();
    assert meta != null;

    String locationName = meta.getDisplayName().replace("§b§l", "");
    Location targetLoc = getLocations(p).get(locationName);

    String targetPlayerName = title.replace("§bSelect a belly for ", "");
    targetPlayerName = targetPlayerName.substring(0, targetPlayerName.length() - 1);

    Player targetPlayer = Bukkit.getPlayer(targetPlayerName);
    if (targetPlayer == null) { p.sendMessage("§8[§b§lVorePlugin§8] §c" + targetPlayerName + " can no longer be found."); return; }
     targetPlayer.teleport(targetLoc);
    if (p.getOpenInventory() == e.getView()) p.closeInventory();
    p.sendMessage("§8[§b§lVorePlugin§8] §aSuccessfully teleported " + targetPlayer.getName() + " to " + locationName + ".");
  }
}
